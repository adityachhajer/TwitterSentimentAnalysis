from django.contrib import admin
from django.urls import path,include
from . import views
urlpatterns = [
    path('', views.analysisHome, name='SentimentAnalysis'),
    path('hashtags', views.hashtags, name='hashtags'),
    path('userdata', views.userdata, name='userdata')

]
